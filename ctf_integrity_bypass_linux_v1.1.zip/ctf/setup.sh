chown root:root chksecure.sh
chown root:root log.txt
chown root:root secret.txt
chown root:root file.txt
chmod u+s chksecure.sh


user=""
echo "Enter unpriv user for CTF! This will add the ability for the user to run the chksecure.sh file in the folder you put it:"
read user 
echo $user
echo "Enter path to chksecure.sh file:"
read path
echo $path
echo "$user ALL = (root) NOPASSWD: $path" | sudo EDITOR='tee -a' visudo

