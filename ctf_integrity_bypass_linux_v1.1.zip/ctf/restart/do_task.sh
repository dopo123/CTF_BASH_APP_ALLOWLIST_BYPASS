echo "1" > file.txt
sleep 5
