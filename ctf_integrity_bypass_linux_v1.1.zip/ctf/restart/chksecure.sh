md5_file="b026324c6904b2a9cb4b88d6d61c81d1"
md5_dotaskfile="02f4f18e00cfafd6737d7b879f2fe931"
count=0

while [ $count -le 3 ]
do
 count=$((count+1))
 md5_tmp=$(md5sum do_task.sh | cut -d " " -f 1)
 if [ "$md5_tmp" == "$md5_dotaskfile" ]
   then
    echo "Integrity checked good! "
    chmod u+s do_task.sh
    chown root:root do_task.sh
    bash do_task.sh
    chmod u-s do_task.sh
    d=$(date)
    echo "$d INFO: No tampering detected! " >> log.txt
   else
    echo "Alert!"
    d=$(date)
    echo "$d Alert: do_task.sh tampered!" >> log.txt
    exit
 fi
done
cat log.txt | tail -n 5


filenum=$(cat file.txt)
if [ "$filenum" == "2" ]
  then
   cat secret.txt
  else
   echo "no secret here!"
fi


