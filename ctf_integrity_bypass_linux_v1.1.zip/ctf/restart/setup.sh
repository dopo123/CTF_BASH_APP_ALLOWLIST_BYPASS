chown root:root chksecure.sh
chown root:root log.txt
chown root:root secret.txt
chown root:root file.txt
chmod u+s chksecure.sh
